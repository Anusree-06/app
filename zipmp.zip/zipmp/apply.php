<html>
    <head>
        <style>
            .sucesss {
            text-align: center;
            font-size: 18px;
            color: #3c763d;
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #d6e9c6;
            border-radius: 5px;
            background-color: #dff0d8;
        }
        </style>
    </head>
</html>
<?php
$servername="localhost";
$username="root";
$password="";
$dbname = "RMS";

$conn=new mysqli($servername,$username,$password, $dbname);
if($conn->connect_error)
{
    die("error connecting".$conn->connect_error);
}

$username = $_POST['username'];
$jobname = $_POST['jobname'];
$company= $_POST['company'];

$sql = "INSERT INTO `$jobname` (username) VALUES ('$username')";
if($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error applying for job: " . $conn->error;
}
$sql = "INSERT INTO `$username` (jobname,company) VALUES ('$jobname', '$company')";
if($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "Error applying for job: " . $conn->error;
}
?>
