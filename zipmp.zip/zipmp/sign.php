<html>
<body>
<button><a href="signin.php">signin</a></button>
<button><a href="signup.php">signup</a></button>
</body>
</html>