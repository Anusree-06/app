<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        .no-listings {
            text-align: center;
            font-size: 18px;
            color: #ff0000;
            margin: 20px;
            padding: 10px;
            border: 1px solid #ff0000;
            border-radius: 5px;
            background-color: #ffe6e6;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            margin-top: 20px;
            color: #322C2B;
        }
        .logout-button {
            background-color: #ff0000; /* Red color for logout button */
            color: white;
            padding: 2px 10px;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s ease;
            margin-top: 25px;
            margin-bottom: 10px;
            margin-left: 1000px; /* Adjust margin-left for positioning */
        }
        .logout-button:hover {
            background-color: #cc0000; /* Darker shade of red on hover */
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #803D3B;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        p {
            text-align: center;
            font-weight: bold;
            font-size: 22px;
            color: green;
            opacity: 0; /* Initially hidden */
            animation: fadeInOut 3s ease forwards; /* Apply animation */
        }
        @keyframes fadeInOut {
            0% { opacity: 0; } /* Start with opacity 0 */
            10% { opacity: 1; } /* Fade in for the first 10% of animation duration */
            90% { opacity: 1; } /* Hold the opacity for the next 80% of animation duration */
            100% { opacity: 0; } /* Fade out for the last 10% of animation duration */
        }
    </style>
</head>
<body>
    <div style="display:flex; background-color:#E4C59E; padding:5px">
    <h2 style="color:#322C2B;margin-left:10px;">ADMIN PANEL</h2>
    <button class="logout-button"><a href="home.html" style="text-decoration:none; color:white">LOGOUT</a></button>
    </div>
    <?php
    $servername="localhost";
    $username="root";
    $password="";

    $conn=new mysqli($servername,$username,$password);
    if($conn->connect_error)
    {
        die("error connecting".$conn->connect_error);
    }
    else
    {
    }
    $sql="CREATE DATABASE IF NOT EXISTS RMS";
    if($conn->query($sql)===TRUE)
    {
        echo"";
    }
    else
    {
        echo"error".$conn->error."<br>";
    }
    mysqli_select_db($conn,"RMS");
    $sql = "CREATE TABLE IF NOT EXISTS USERS( id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,Username VARCHAR(30),Password VARCHAR(30),name VARCHAR(20),address VARCHAR(100),skills VARCHAR(300),languages VARCHAR(300),age VARCHAR(30),email VARCHAR(30),phone VARCHAR(30), resume VARCHAR(255))";
if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "error" . $conn->error . "<br>";
}
    echo "
        <h1>JOB LISTINGS</h1>";
        $sql="CREATE TABLE IF NOT EXISTS JOBDETAILS(id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,jname VARCHAR(300),jsummary VARCHAR(200),jreq VARCHAR(200),expandedu VARCHAR(200),jloc VARCHAR(70),cname VARCHAR(30),uname VARCHAR(30), image VARCHAR(255))";
if($conn->query($sql)===TRUE)
{
	echo"";
		
}
else
{
	echo"error".$conn->error."<br>";
	
}

    $sql="SELECT * FROM JOBDETAILS";
    $result=$conn->query($sql);
    if($result->num_rows>0)
    {
        echo "
        <div STYLE=\"padding:20px;align:center;\">
        <table border='1' STYLE=\"padding:2px;text-align:center;\" >
        <tr>
        <th STYLE=\"padding:3px\">JOB NAME</th>
        <th STYLE=\"padding:3px\">SUMMARY</th>
        <th STYLE=\"padding:3px\">REQUIREMENTS</th>
        <th STYLE=\"padding:3px\">EDUCATION AND EXPERIENCE</th>
        <th STYLE=\"padding:3px\">LOCATION</th>
        <th STYLE=\"padding:3px\">COMPANY NAME</th>
        </tr>";
        while($row=$result->fetch_assoc())
        {
            echo"<tr>
            <td STYLE=\"padding:3px\">".$row['jname']."</td>    
            <td STYLE=\"padding:7px\">".$row['jsummary']."</td>
            <td STYLE=\"padding:5px\">".$row['jreq']."</td>
            <td STYLE=\"padding:7px\">".$row['expandedu']."</td>    
            <td STYLE=\"padding:3px\">".$row['jloc']."</td>
            <td STYLE=\"padding:3px\">".$row['cname']."</td>
            </tr>";
        }
        echo"</table></div>";
    }
    else 
    {
        echo"<div class='no-listings'>No listings for now!</div>";
    }

   

    // Fetch users from the database
    $sql="SELECT ID, Username FROM USERS";
    $result=$conn->query($sql);
    if($result->num_rows>0) {
        echo "
        <div STYLE=\"padding:20px;align:center;\">
        <h1>USERS</h1>";
        echo"<form method=\"post\"> <!-- Each user is inside a separate form -->
        <table border='1' STYLE=\"padding:2px;text-align:center;\" >
        <tr>
        <th STYLE=\"padding:3px\">USER NAME</th>
        <th STYLE=\"padding:3px\">REMOVE USER</th>
        </tr>";
        while($row=$result->fetch_assoc()) {
            echo "
            <tr>
            <td STYLE=\"padding:3px\">".$row['Username']."</td>   
            <td STYLE=\"padding:5px\">
            <input type=\"hidden\" name=\"user_username\" value=\"".$row['Username']."\"> <!-- Hidden input to pass user username -->
            <input type=\"submit\" name=\"remove_user_".$row['ID']."\" value=\"REMOVE USER\"> <!-- Unique submit button -->
            </td>
            </tr>
            ";
        }
        echo "</table></form></div>";
    } else {
        echo "<p>No users found!</p>";
    }
 // Check if form is submitted to remove a user
 foreach($_POST as $key => $value) {
    if(strpos($key, 'remove_user_') !== false) { // Check if the form submission is for removing a user
        $user_id = substr($key, strlen('remove_user_')); // Extract the recruiter ID from the form submission key
        // Perform the removal operation for the recruiter with this ID
        $sql = "DELETE FROM USERS WHERE ID = '$user_id'";
        if($conn->query($sql) === TRUE) {
            echo "<p>User removed successfully!</p>";
            // Redirect or update page as needed
        } else {
            echo "Error removing user: " . $conn->error;
        }
    }
}

$sql = "CREATE TABLE IF NOT EXISTS RECRUITERS( id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,Username VARCHAR(30),Password VARCHAR(30))";
if ($conn->query($sql) === TRUE) {
    echo "";
} else {
    echo "error" . $conn->error . "<br>";
}
    $sql = "SELECT ID, Username FROM RECRUITERS";
    $result=$conn->query($sql);
    if($result->num_rows > 0) {
        echo "
        <div STYLE=\"padding:20px;align:center;\">
        <h1>RECRUITERS</h1><form method=\"post\"> <!-- Each recruiter is inside a separate form -->
        <table border='1' STYLE=\"padding:2px;text-align:center;\" >
        <tr><th STYLE=\"padding:3px\">RECRUITER/COMPANY NAME</th>
        <th STYLE=\"padding:3px\">REMOVE RECRUITER/COMPANY</th>
        </tr>";
        while($row=$result->fetch_assoc()) {
            echo "
            
            <tr>
            <td STYLE=\"padding:3px\">".$row['Username']."</td>   
            <td STYLE=\"padding:5px\">
            <input type=\"hidden\" name=\"recruiter_username\" value=\"".$row['Username']."\"> <!-- Hidden input to pass recruiter username -->
            <input type=\"submit\" name=\"remove_recruiter_".$row['ID']."\" value=\"REMOVE RECRUITER\"> <!-- Unique submit button -->
            </td>
            </tr>
            ";
        }
        echo "</table></form></div>";
    } else {
        echo "<p>No recruiters found!</p>";
    }

    // Check if form is submitted to remove a recruiter
    foreach($_POST as $key => $value) {
        if(strpos($key, 'remove_recruiter_') !== false) { // Check if the form submission is for removing a recruiter
            $recruiter_id = substr($key, strlen('remove_recruiter_')); // Extract the recruiter ID from the form submission key
            // Perform the removal operation for the recruiter with this ID
            $sql = "DELETE FROM RECRUITERS WHERE ID = '$recruiter_id'";
            if($conn->query($sql) === TRUE) {
                echo "<p>Recruiter removed successfully.</p>";
                // Redirect or update page as needed
            } else {
                echo "Error removing recruiter: " . $conn->error;
            }
        }
    }
    ?>
</body>
</html>