<html>
<body>
<button><a href="signinr.php">signin</a></button>
<button><a href="signupr.php">signup</a></button>
</body>
</html>